
package voicemail.system;

public class VoicemailSystem {
    public static void main(String[] args) {
        //we create two mailboxes, with a default greeting messages
        Mailbox m1 = new Mailbox("hello");
        Mailbox m2 = new Mailbox("hello, leave a message");
        //we create two phones, dialer and reciver; we give them a telephone number and a mailbox object
        Phone dialer = new Phone(001, m1);
        Phone reciever = new Phone(002, m2);
        
        // dialer calls reciever; the phone is not picked up, so the greeting message form the mailbox will be diaplayed

        dialer.dial(reciever);
        // reciver can use the mailboxinterface method to acess the message dialer has left
        reciever.mailboxinterface();
    
    }
    
}
