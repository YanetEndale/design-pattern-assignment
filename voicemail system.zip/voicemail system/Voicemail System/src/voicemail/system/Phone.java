
package voicemail.system;

import java.util.Scanner;


public class Phone {
    private int telephoneNumber;
    private Mailbox connectedMailbox;
    private int state;
    private static final int PICKED_UP = 0;
    private static final int RINGING = 1;
    private static final int NOT_PICKED_UP = 2;
    
    public Phone(int telephone, Mailbox mail){
        this.connectedMailbox = mail;
        this.telephoneNumber = telephone;
        this.state = 2;
        
    }
    
    public void dial(Phone p){
        switch (state) {
            case NOT_PICKED_UP:
                Scanner msg = new Scanner(System.in);
                System.out.println(p.getConnectedMailbox().getGreetingMessage());
                String m = msg.next();
                recordMessage(p, m);
                break;
            case PICKED_UP:
                System.out.println("phone is picked up...");
                break;
            case RINGING:
                System.out.println("phone is ringing....");
                break;
            default:
                break;
        }
        
    }
    public void recordMessage(Phone p ,String message){
        Mailbox recieverMailbox = p.getConnectedMailbox();
        recieverMailbox.addMessage(message);
        
    }
    
    public void mailboxinterface(){
        
        while (true){
        System.out.println("-------------------------------------------");
        System.out.println("------welcome to the mailbox interface-----");
        System.out.println("Your phone number: "+ this.telephoneNumber);
        System.out.println("-----press 1-----to read new message-----");
        System.out.println("-----press 2-----to view all stored messages--");
        Scanner reply = new Scanner(System.in);
        int n = reply.nextInt();
        
       
        if (n == 1) {
            String retrivedMsg = this.connectedMailbox.retriveMessage();
            System.out.println(retrivedMsg);
            System.out.println("-----press 1-----to keep the message-----");
            System.out.println("-----press 2-----to delete the message---");
            Scanner reply2 = new Scanner(System.in);
            int r2 = reply2.nextInt();
            if (r2 == 1) {
                this.connectedMailbox.keepretrivedMessage();
                
            }
            else if (r2 == 2) {
                this.connectedMailbox.deleteretrivedMessage();
                
            }
        }
        else if (n==2) {
            this.connectedMailbox.getAllStoredMessages();
        }
    }
    }
    public Mailbox getConnectedMailbox(){
        return this.connectedMailbox;
    }
    
}
