
package voicemail.system;

import java.util.ArrayList;


public class Mailbox {
    private final String greetingMessage;
    private ArrayList newMessages;
    private ArrayList storedMessages;
    
    public Mailbox(String greet){
        
        this.greetingMessage = greet;
        this.storedMessages = new ArrayList();
        this.newMessages = new ArrayList();
    }
    
    public void addMessage(String message){
        
        this.newMessages.add(message);
    }
    public String retriveMessage(){
        String retrivedMesasge = (String) this.newMessages.get(this.newMessages.size() - 1);
        return retrivedMesasge;
    }
    public void deleteretrivedMessage(){
        this.newMessages.remove(this.newMessages.size() - 1);
        
    }
     public void keepretrivedMessage(){
        this.storedMessages.add((String) this.newMessages.get(this.newMessages.size() - 1));
    }
     public void getAllStoredMessages(){
         for (int i = 0; i < this.storedMessages.size(); i++) {
             System.out.println("message number:"+ (i + 1) +"--"+this.storedMessages.get(i));
         }
     }
     public String getGreetingMessage(){
         return this.greetingMessage;
     }
    
}
